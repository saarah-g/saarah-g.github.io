#ifndef __GPIO_INIT_H_
#define __GPIO_INIT_H_

#include "xgpio.h"		// Added for xgpio object definitions

XStatus initGpio(void);

XGpio SEG7_HEX_OUT;
XGpio SEG7_SEL_OUT;
XGpio P_BTN_LEFT;
XGpio P_BTN_RIGHT;
XGpio P_BTN_UP;
XGpio P_BTN_DOWN;
XGpio LED_OUT;
XGpio SLIDE_SWITCHES;
XGpio VGA_COLOUR;
XGpio VGA_REGION;
XGpio REG_0;
XGpio REG_1;
XGpio REG_2;
XGpio REG_3;
XGpio REG_4;
XGpio REG_5;
XGpio REG_6;
XGpio REG_7;
XGpio REG_8;
XGpio REG_9;
XGpio REG_10;
XGpio REG_11;

#endif
