#include "gpio_init.h"

XStatus initGpio(void) {
	XStatus status;

	/* Note that the Xgpio objects SEG7_HEX_OUT and SEG7_SEL_OUT
	 * have been declared in the gpio_init.h header file,
	 * but make sure you confirm that the IDs used to initialize
	 * the GPIOs here are correct
	 */
	status = XGpio_Initialize(&SEG7_HEX_OUT, 0);
	if (status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	status = XGpio_Initialize(&SEG7_SEL_OUT, 1);
	if (status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	status = XGpio_Initialize(&P_BTN_LEFT, 4);
	if (status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	status = XGpio_Initialize(&P_BTN_RIGHT, 5);
	if (status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	status = XGpio_Initialize(&P_BTN_UP, 6);
	if (status != XST_SUCCESS) {
		return XST_FAILURE;
	}
	status = XGpio_Initialize(&P_BTN_DOWN, 3);
	if (status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	status = XGpio_Initialize(&LED_OUT, 2);
	if (status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	status = XGpio_Initialize(&REG_0, 7);
	if (status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	status = XGpio_Initialize(&REG_1, 10);
	if (status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	status = XGpio_Initialize(&REG_2, 11);
	if (status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	status = XGpio_Initialize(&REG_3, 12);
	if (status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	status = XGpio_Initialize(&REG_4, 13);
	if (status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	status = XGpio_Initialize(&REG_5, 14);
	if (status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	status = XGpio_Initialize(&REG_6, 15);
	if (status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	status = XGpio_Initialize(&REG_7, 16);
	if (status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	status = XGpio_Initialize(&REG_8, 17);
	if (status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	status = XGpio_Initialize(&REG_9, 18);
	if (status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	status = XGpio_Initialize(&REG_10, 8);
	if (status != XST_SUCCESS) {
		return XST_FAILURE;
	}
	status = XGpio_Initialize(&REG_11, 9);
	if (status != XST_SUCCESS) {
		return XST_FAILURE;
	}
	return XST_SUCCESS;
}
