/* File Name: ledsetup.c
 * Project Name: Traffic Lights Application
 * Target Device/Platform: Basys3 Board (with Microblaze processor on the Artix-7 FPGA)
 * Tool Version: Xilinx SDK 2015.2
 * Name: Maurice Rahme
 * Company: University of Edinburgh
 * Creation Date and Time: 09/11/2017; 10:07
 *
 * Description:
 * This source file contains the code to write to the LEDs. By default, it will write using the variable
 * "ledlight", which is defined in each individual state within the trafficlights() state machine. However,
 * it will turn on LEDs 6 and 7 if any pedestrian button is pressed. This function is called within the main,
 * before trafficlights(), and hence also makes use of the "global.h" and the "gpio_init.h" header files.
 * */

#include <stdio.h>
#include "platform.h"
#include "gpio_init.h"
#include "global.h"

// Condition setup for the LED - this avoids uneven LED brightness caused by overwriting the binary LED mask if the PD button is pressed
int ledsetup() {
	if (pbtn1 == 0) {
		XGpio_DiscreteWrite(&LED_OUT, 1, ledlight); //illuminate LEDs, object defined at each state
	} else {
		XGpio_DiscreteWrite(&LED_OUT, 1, (ledlight + 0b0000001100000000)); //if pedestrian button is pressed, also illuminate LED - avoids dim LED
	}
	return 0;
}
