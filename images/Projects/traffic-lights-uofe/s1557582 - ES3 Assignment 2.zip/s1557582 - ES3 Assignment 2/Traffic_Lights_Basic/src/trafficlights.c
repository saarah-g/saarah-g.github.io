/* File Name: trafficlights.c
 * Project Name: Traffic Lights Application
 * Target Device/Platform: Basys3 Board (with Microblaze processor on the Artix-7 FPGA)
 * Tool Version: Xilinx SDK 2015.2
 * Name: Maurice Rahme
 * Company: University of Edinburgh
 * Creation Date and Time: 09/11/2017; 10:07
 *
 * Description:
 * This source file contains the main state machine operation. It is called within the main() function.
 * It works as a state machine comprised of 8 states; each state employs a different traffic light operation
 * as detailed in the flowchart within the User Guide. You can also find the specific traffic light operation
 * written as a comment above each "case" in the switch case.
 *
 * displayNumber is called before the switch case statement to show a countdown until the next state for each
 * traffic light operation. Notice that this call concerns all states but 8, as there is a unique state 8
 * implementation which allows the SSDisplay output to blink during the final 2 seconds of the pedestrian green light
 * operation.
 *
 * For the extra feature, displayNumber is changed for states 2 and 6, where it displays a variable countdown dependent on
 * the number of pedestrian nodes that indicated a need for crossing.
 *
 * Notably, at the end of state 7, the system sets the state to 0 and resets the counter, thus completing the loop.
 *
 * At states 0 and 4, at the end of their respective 2 second counters, the system checks whether a pedestrian button
 * has been pressed. If so, it sends the state to 8, which is the pedestrian green light state, and sets a variable
 * named "prevstate" to 0 or 4 respectively.
 *
 * state 8 starts by setting the push button(s) to 0; this turns off the push button flag LEDs, and avoids erroneous operation.
 * State 8 uses a different counter named "timer", set to last up to 1250 counts, which is equivalent to 5 seconds.
 * During the first 750 counts (3 seconds) of "timer", the pedestrian light is displayed to be green, and the countdown
 * is shown on the SSDisplay on the Basys 3 Board, along with the LED mapped to the pedestrian green light.
 * For the final 500 counts (2 seconds), a new counter named "blinkercount" is used to switch a "blink" variable
 * between 1 and 0, starting from 0 at blinkercuont = 0. This, in conjunction with a switch case at state 8
 * which takes "blink" as an input, allows for a blink operation to be carried out. For blink = 0, the system will
 * blink "OFF", meaning that the pedestrian light will be displayed white, the LED mapped to it will be turned off and
 * displayNumber will show a blank (this is done by writing 10000 to it and changing "seg7_display.c" to show NUMBER_BLANK
 * for values above 9999). For blink = 1, the system will blink "ON", meaning that the pedestrian light will be green, its
 * mapped LED will be turned on and the SSDisplay will once again show the countdown.
 *
 * At the end of state 8's 1250 counts, the system checks the value of "prevstate". If it is 0, then it sets the state to 1, for
 * an R1Y1 operation as specified for the assessment. If prevstate = 4, then it will set the state to 5 for an R2Y2 operation.
 * */

#include <stdio.h>
#include "platform.h"
#include "gpio_init.h"
#include "seg7_display.h"
#include "xil_types.h"
#include "global.h"

// State machine code - this performs different region colouring and SSD/LED display operations depending on the current state
int trafficlights() {

	/* SSDisplay code:
	 * Displays a countdown from 2 --> 0 for all traffic lights,
	 * with the exception of the pedestrian green light, for which
	 * the SSDisplay will show a countdown from 5 --> 0
	 * This is done within case 8
	 */
	if (state != 8) {
		displayNumber(((4 * (countermax - counter)) / 1000) + 1); // to avoid copy/pasting identical code in each case for SSDisplay
	}
	// End of SSDisplay code

	// Switch case function to program state machine
	switch (state) {

	// State 0: Red 1, Red 2, Pedestrian Red --> next state = 1 or 8 depending on pbtn1
	case 0:

		XGpio_DiscreteWrite(&REG_0, 1, colourred); // Red1
		XGpio_DiscreteWrite(&REG_1, 1, colourwhite); // overwrite possible unnecessary region colour

		XGpio_DiscreteWrite(&REG_6, 1, colourred); // Red2
		XGpio_DiscreteWrite(&REG_7, 1, colourwhite); // overwrite possible unnecessary region colour

		XGpio_DiscreteWrite(&REG_4, 1, colourred); // Pedestrian Red

		ledlight = 0b1100000010000011; // Red1 PDbtnOFF PRed Red2

		/*Pedestrian push button condition code:
		 * sends to state 8 if pbtn1 == 1 at the
		 * end of the 2second count
		 * Also signals that the previous state was 0,
		 * to allow state 8 to decide which state to go to next
		 */
		if (pbtn1 == 1 && counter >= countermax) {
			state = 8;
			prevstate = 0;
		}
		// End of condition code

		break;

		// State 1: Red 1, Yellow 1, Red 2, Pedestrian Red --> next state = 2
	case 1:

		XGpio_DiscreteWrite(&REG_1, 1, colouryellow);  // Red1Yellow1
		XGpio_DiscreteWrite(&REG_4, 1, colourred); // Pedestrian Red -- called again to overwrite in case pedestrian light has just been green

		ledlight = 0b1111000010000011; // Red1Yellow1 PDbtnOFF PRed Red2
		break;

		// State 2: Green 1, Red 2, Pedestrian Red --> next state = 3
	case 2:

		XGpio_DiscreteWrite(&REG_0, 1, colourwhite); // overwrite possible unnecessary region colour
		XGpio_DiscreteWrite(&REG_1, 1, colourwhite); // overwrite possible unnecessary region colour
		XGpio_DiscreteWrite(&REG_2, 1, colourgreen); // Green 1

		ledlight = 0b0000110010000011; // Green1 PDbtnOFF PRed Red2
		break;

		// State 3: Yellow 1, Red 2, Pedestrian Red --> next state = 4
	case 3:

		XGpio_DiscreteWrite(&REG_1, 1, colouryellow);      // Yellow1
		XGpio_DiscreteWrite(&REG_2, 1, colourwhite); // overwrite possible unnecessary region colour

		ledlight = 0b0011000010000011; // Yellow1 PDbtnOFF PRed Red2
		break;

		// State 4: Red 1, Red 2, Pedestrian Red --> next state = 5 or 8 depending on pbtn1
	case 4:

		XGpio_DiscreteWrite(&REG_0, 1, colourred); // All Red from Red1 -- provide pedestrian condition here
		XGpio_DiscreteWrite(&REG_1, 1, colourwhite); // overwrite possible unnecessary region colour
		XGpio_DiscreteWrite(&REG_4, 1, colourred); // Pedestrian Red -- called again to overwrite in case pedestrian light has just been green

		ledlight = 0b1100000010000011; // Red1 PDbtnOFF PRed Red2

		/*Pedestrian push button condition code:
		 * sends to state 8 if pbtn1 == 1 at the
		 * end of the 2second count
		 * Also signals that the previous state was 0,
		 * to allow state 8 to decide which state to go to next
		 */
		if (pbtn1 == 1 && counter >= countermax) {
			state = 8;
			prevstate = 4;
		}
		// End of condition code

		break;

		// State 5: Red 1, Red 2, Yellow 2, Pedestrian Red --> next state = 6
	case 5:

		XGpio_DiscreteWrite(&REG_7, 1, colouryellow); // Red2Yellow2
		XGpio_DiscreteWrite(&REG_4, 1, colourred); // Pedestrian Red -- called again to overwrite in case pedestrian light has just been green

		ledlight = 0b1100000010001111; // Red1 PDbtnOFF PRed Yellow2Red2
		break;

		// State 6: Red 1, Green 2, Pedestrian Red --> next state = 7
	case 6:

		XGpio_DiscreteWrite(&REG_6, 1, colourwhite); // overwrite possible unnecessary region colour
		XGpio_DiscreteWrite(&REG_7, 1, colourwhite); // overwrite possible unnecessary region colour
		XGpio_DiscreteWrite(&REG_8, 1, colourgreen); //  Green2

		ledlight = 0b1100000010110000; // Red1 PDbtnOFF PRed Green2
		break;

		// State 7: Red 1, Yellow 2, Pedestrian Red --> next state = 0
	case 7:

		XGpio_DiscreteWrite(&REG_7, 1, colouryellow);  // Yellow2
		XGpio_DiscreteWrite(&REG_8, 1, colourwhite); // overwrite possible unnecessary region colour

		ledlight = 0b1100000010001100; // Red1 PDbtnOFF PRed Yellow2

		if (counter >= countermax) { // this is here to avoid counter skipping straight to state 1 from state 0
			state = 0;
			counter = 0;
		}
		break;

		// State 8: Red 1, Red 2, Pedestrian Green --> next state = 1 or 5 dependent on prevstate
	case 8:
		pbtn1 = 0; // turns off pbtn and corresponding LED

		/* Pedestrian Light Timer
		 * Pedestrian timer max value, timermax set to 5sec instead of the usual 2sec used for other lights
		 * In this case, fomr 0-3sec, the pedestrian light is lit green, as per the first if statement
		 * In the last 2 seconds of the 5sec timer, the green light blinks along with the corresponding
		 * Pedestrian LED and the SSDisplay counter
		 */
		// First 3sec of 5sec timer
		if (timer <= (timermax - countermax)) {
			XGpio_DiscreteWrite(&REG_4, 1, colourgreen); // Pedestrian Green
			displayNumber(((4 * (timermax - timer)) / 1000) + 1); // adjusted here for timer value
			ledlight = 0b1100000001000011; // Red1 PDbtnOFF PGreen Red2
			//test = 1; -- for debugging

			// last 2sec of 5sec timer
		} else if (timer <= timermax) {

			/*Blinker code:
			 * blink = 0 --> write white (blink off)
			 * blink = 1 --> write green (blink on)
			 * rotate blink value done in hwtimerISR.c
			 */
			switch (blink) {
			case 0:
				XGpio_DiscreteWrite(&REG_4, 1, colourwhite); // Pedestrian White Blink
				ledlight = 0b1100000000000011; // PDGreen Blink OFF
				displayNumber(10000); // Blank (>9999) for Blink OFF
				break;
				//test = 2; -- for debugging
			case 1:
				XGpio_DiscreteWrite(&REG_4, 1, colourgreen); // Pedestrian Green Blink
				ledlight = 0b1100000001000011; // PDGreen Blink ON
				displayNumber(((4 * (timermax - timer)) / 1000) + 1); // Blink ON
				//test = 3; -- for debugging
				break;
			default:
				break;
			}
			// End of blinker code

		}
		// End of Pedestrian Light Timer

		/*Pedestrian prevstate condition code:
		 * sends to state 5 if prevstate == 4 at the
		 * end of the 5second count
		 * Otherwise sends to state 1 at the end of the
		 * 5 second count
		 */
		if (prevstate == 4 && timer >= timermax) { // >= fixes broken condition where case defaults
			state = 5; // sends to R2Y2 R1 as per the assignment

		} else if (timer >= timermax) { // >= fixes broken condition where case defaults
			state = 1; // sends to R1Y1 R2 as per the assignment

		}
		// End of prevstate condition code

		break;

	default:
		xil_printf("break"); // debugging tool to show if switch case has broken, indicating a counter malfunction
		break;

	}
	return 0;
}
