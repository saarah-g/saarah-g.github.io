/* File Name: hwtimerISR.c
 * Project Name: Traffic Lights Application
 * Target Device/Platform: Basys3 Board (with Microblaze processor on the Artix-7 FPGA)
 * Tool Version: Xilinx SDK 2015.2
 * Name: Maurice Rahme
 * Company: University of Edinburgh
 * Creation Date and Time: 09/11/2017; 10:07
 *
 * Description:
 * This source file mainly serves as a means of implementing counters and inputs to be used in the trafficlights() state machine.
 * It includes the header file "gpio_init.h" to read the push button inputs and hence create flags.
 * It also includes the "global.h" header file as it uses many of the variable definitions within it.
 * It also includes the "seg7_display.h" header file to declare displayDigit(), which is used to allow displayNumber()
 * to work within trafficlights()
 *
 * The main state machine counter is called "counter". This is the first counter in this file.
 * This counter resets every 500 counts, granting most state operations a 2 second duration.
 * The pedestrian green light extended counter is called "timer". This is the next counter in the file.
 * This counter lasts 1250 counts, granting the pedestrian green light a 2 second duration
 * "blinkercount" is another counter that is engaged within "timer" to switch a case variable between 0 and 1
 * every 50 counts, which allows for the implementation of a blink operation within trafficlights()
 *
 * There is also a debugging counter named "extracounter" at the end of this source file.
 *
 * */

#include <stdio.h>
#include "platform.h"
#include "gpio_init.h"
#include "seg7_display.h"
#include "xil_types.h"
#include "global.h"

/* Interrupt code -- this contains the essential counters for this program, which control the main count loop,
 * the pedestrian light counter, the blink counter and the debugger counter*/
void hwTimerISR(void *CallbackRef) {

	// This is declared here as an SSDisplay function
	displayDigit();

	// receive input pedestrian button
	if (XGpio_DiscreteRead(&P_BTN_LEFT, 1)) {
		pbtn1 = 1;
	}

	// main state-selecting counter
	if (counter > countermax) {
		counter = 0;
		timer = 0;
		state++;

	} else if (state != 8) { // counter stops at state 8 as timer starts
		counter++;

	}
	// end of main state-selecting counter

	// state 8 timer for extended pedestrian light
	if (state == 8) {
		counter = 0;
		if (timer >= timermax) {
			timer = 0;
			blink = 0; /* blink is pre-set to 0 since the blink would otherwise be delayed by 50 interrupts,
			as that's how long it takes for blink 1 to be set @ blinkerhalf*/
			blinkercount = 0;
		} else if (timer >= (timermax - countermax)) {

            /* pedestrian light - blinker counter:
             * this counter switches blink between 1 and 0 after each 50 interrupts,
             * up to a maximum of 500 interrupts, i.e when the 2 remaining seconds of the
             * original 5 have ended.
             */
			if (blinkercount >= blinkermax) {
				if (blink == 0){
					blink = 1;
				}else if (blink == 1){
					blink = 0;
				}
				blinkercount = 0;
			} else {
				blinkercount++;
			}
			// end of blinker counter

			timer++;
		} else {
			timer++;
		}
	}
	// end of state 8 timer



	/* Debugging Counter:
	 * Used for debugging by printing certain parameters.
	 * The counter is setu up this way to display the desired
	 * debugger variables on every interrupt, thus granting me
	 * an unobstructed and involved view of the code
	 */
//	extracounter++;
//	if (extracounter <= countermax) {
		//xil_printf("%d  %d  %d  %d\n", blink, blinkercount, timer, test);
		//xil_printf ("%d\n",state);
		//xil_printf ("%d\n",pbtn1);
		//xil_printf ("%d\n",counter);
		//xil_printf ("%d\n",blink);
		//xil_printf ("%d\n",blinkercount);
		//xil_printf ("%d\n",timer);
		//xil_printf ("%d\n",prevstate);

//	} else {
//		extracounter = 0;
//	}
	// end of debugging counter

}
