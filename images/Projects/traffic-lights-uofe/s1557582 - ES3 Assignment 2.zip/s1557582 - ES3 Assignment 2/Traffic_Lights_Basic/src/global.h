// Global variables ; declare required variables. Define them in the main

// Colours
extern u16 colourred;
extern u16 colouryellow;
extern u16 colourgreen;
extern u32 colourwhite;

// Main State Machine
extern u16 volatile counter; // main state machine counter for traffic light operations
extern u16 countermax; // equivalent to 2 seconds according to interrupt time of 0.04sec
extern u16 volatile state; // this is a state variable for the main traffic light operation
extern u16 volatile prevstate; /* this is used after the PDGreen condition, to tell the state
 machine whether to engage Traffic Light System 1 or 2 based on the previously engaged TL */

// Pedestrian Light - Basic Operations
extern u16 volatile timer; // extended counter for pedestrian light
extern u16 timermax; // equivalent to 5 seconds

// Pedestrian Light - Blink Operations
extern u16 volatile blinkercount;
extern u16 blinkermax;/* "blink" 5 times means once every 100 counts, means one green one white in 100 counts,
 means 50 counts per colour */
extern u16 volatile blink; // this is a state variable for the pedestrian button blink operation

// Input Buttons
extern u8 volatile pbtn1; // pedestrian button 1


// LED Light Mapping
extern u16 volatile ledlight; // count variable dedicated to LED OUT that is used to show the corresponding traffic lights

// Debuggers
extern u16 extracounter; // for debugging
extern u8 test; // for debugging

//
//
// End of Global Variables
