/* File Name: global.h
 * Project Name: Traffic Lights Application
 * Target Device/Platform: Basys3 Board (with Microblaze processor on the Artix-7 FPGA)
 * Tool Version: Xilinx SDK 2015.2
 * Name: Maurice Rahme
 * Company: University of Edinburgh
 * Creation Date and Time: 09/11/2017; 10:07
 *
 * Description:
 * Global variables ; declare required variables here. Define them in main().
 * */


// Colours
extern u16 colourred;
extern u16 colouryellow;
extern u16 colourgreen;
extern u32 colourwhite;

// Main State Machine
extern u16 volatile counter; // main state machine counter for traffic light operations
extern u16 countermax; // equivalent to 2 seconds according to interrupt time of 0.04sec
extern u16 volatile state; // this is a state variable for the main traffic light operation
extern u16 volatile prevstate; /* this is used after the PDGreen condition, to tell the state
 machine whether to engage Traffic Light System 1 or 2 based on the previously engaged TL */

// Pedestrian Light - Basic Operations
extern u16 timer; // extended counter for pedestrian light
extern u16 timermax; // equivalent to 5 seconds

// Pedestrian Light - Blink Operations
extern u16 blinkercount;
extern u16 blinkermax;/* "blink" 5 times means once every 100 counts, means one green one white in 100 counts,
 means 50 counts per colour */
extern u16 volatile blink; // this is a state variable for the pedestrian button blink operation

// Priority System Counters - EXTRA FEATURE
extern u16 carprioritycounter;
extern u16 priorityvalue;
extern u16 carprioritymax;
extern u16 carprioritymedhigh;
extern u16 carprioritymedlow;
extern u16 carpriorityminhigh;
extern u16 carpriorityminlow;
extern u8 volatile priority;

// Input Buttons
extern u8 volatile pbtn1; // pedestrian button 1
extern u8 volatile pbtn2; // pedestrian button 2
extern u8 volatile pbtn3; // pedestrian button 3
extern u8 volatile pbtn4; // pedestrian button 4


// LED Light Mapping
extern u16 volatile ledlight; // count variable dedicated to LED OUT that is used to show the corresponding traffic lights

// Debuggers
extern u16 extracounter; // for debugging
extern u8 test; // for debugging

//
//
// End of Global Variables
