/* File Name: main.c
 * Project Name: Traffic Lights Application
 * Target Device/Platform: Basys3 Board (with Microblaze processor on the Artix-7 FPGA)
 * Tool Version: Xilinx SDK 2015.2
 * Name: Maurice Rahme
 * Company: University of Edinburgh
 * Creation Date and Time: 09/11/2017; 10:07
 *
 * Description:
 * This source file contains the main operation for the traffic lights application, along with all
 * variable definitions. This source file calls the initGpio() and setUpInterruptSystem()
 * functions to initialize all XGpio variables and functions, and to implement the counters
 * that rely on the interrupt system. These functions are declared within the "gpio_init.h" header file,
 * and the global variables are declared in the "global.h" header file.
 * Within an infinite while loop, the main calls ledsetup(), which is used to map the LEDs
 * to the different traffic light operations. It also calls trafficlights() to perform the state machine
 * operation, and finally, as an extra feature, it defines the "priority" variable, which is used in hwtimerISR() to
 * decide the car green light duration depending on the number of pedestrian nodes requesting to cross the street.
 * The "seg7_display.h" header file is called since the called trafficlights() function writes to the SSDisplay.
 * */



#include <stdio.h>
#include "platform.h"
#include "gpio_init.h"
#include "seg7_display.h"
#include "xil_types.h"
#include "global.h" // for cross-function Global variable declaration

// Global variables ; define required variables

// Colours
u16 colourred = 0b0000111100000000;
u16 colouryellow = 0b0000111111110000;
u16 colourgreen = 0b0000000011110000;
u32 colourwhite = 0xFFFFFF;

// Main State Machine
u16 volatile counter = 0; // main state machine counter for traffic light operations
u16 countermax = 500; // equivalent to 2 seconds according to interrupt time of 0.04sec
u16 volatile state = 0; // this is a state variable for the main traffic light operation
u16 volatile prevstate = 0; /* this is used after the PDGreen condition, to tell the state
 machine whether to engage Traffic Light System 1 or 2 based on the previously engaged TL */

// Pedestrian Light - Basic Operations
u16 timer = 0; // extended counter for pedestrian light
u16 timermax = 1250; // equivalent to 5 seconds

// Pedestrian Light - Blink Operations
u16 blinkercount = 0;
u16 blinkermax = 50; /* "blink" 5 times means once every 100 counts, means one green one white in 100 counts,
 means 50 counts per colour */
u16 volatile blink; // this is a state variable for the pedestrian button blink operation

// Priority System Counters - EXTRA FEATURE
u16 carprioritycounter = 0;
u16 priorityvalue;
u16 carprioritymax = 1500;
u16 carprioritymedhigh = 1250;
u16 carprioritymedlow = 1000;
u16 carpriorityminhigh = 750;
u16 carpriorityminlow = 500;
u8 volatile priority = 0;

// Input Buttons
u8 volatile pbtn1 = 0; // pedestrian button 1
u8 volatile pbtn2 = 0; // pedestrian button 2
u8 volatile pbtn3 = 0; // pedestrian button 3
u8 volatile pbtn4 = 0; // pedestrian button 4

// LED Light Mapping
u16 volatile ledlight = 0; // count variable dedicated to LED OUT that is used to show the corresponding traffic lights

// Debuggers
u16 extracounter = 0; // for debugging
u8 test = 0; // for debugging

//
//
// End of Global Variables



//
//
//
// Declared Used Functions:
//
// initialization code
int initialize();

// interrupt setup
int setUpInterruptSystem();


// State machine code - this performs different region colouring and SSD/LED display operations depending on the current state
int trafficlights();

// Condition setup for the LED - this avoids uneven LED brightness caused by overwriting the binary LED mask if the PD button is pressed
int ledsetup();

//
//Main
int main() {

	init_platform();

	// initialization code - Initialize the GPIOs and setup the Interrupt System
	initialize();

	// this is the main while(1) loop
	while (1) {

		/* Condition setup for the LED - this avoids uneven LED brightness
		 * caused by overwriting the binary LED mask if the PD button is pressed
		 */
		ledsetup();

		priority = pbtn1 + pbtn2 + pbtn3 + pbtn4; /* "priority" is used to determine the length of the cars' green light duration
		based on the number of nodes whose push button has been pressed. This variable will range from 0 to 4 as
		there are 4 pedestrian nodes in a T-junction, and there are conveniently 4 free buttons on the Basys 3 board*/

		//State Machine Code
		trafficlights();
	}

	cleanup_platform();
	return 0;
}

// Defined Used Functions:
//
//initialization code
int initialize() {
	int status;

	// Initialize the GPIOs
	status = initGpio();
	if (status != XST_SUCCESS) {
		print("GPIOs initialization failed!\n\r");
		cleanup_platform();
		return 0;
	}

	// Setup the Interrupt System
	status = setUpInterruptSystem();
	if (status != XST_SUCCESS) {
		print("Interrupt system setup failed!\n\r");
		cleanup_platform();
		return 0;
	}
	return 0;
}




