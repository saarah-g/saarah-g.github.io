#ifndef __SEG7_DISPLAY_H_
#define __SEG7_DISPLAY_H_

#include "xgpio.h"		// Added for xgpio object definitions

// Definitions for 7-segment BCD codes
#define DIGIT_BLANK		0xFF
#define DIGIT_ZERO 		0xC0
#define DIGIT_ONE  		0xF9
#define DIGIT_TWO  		0xA4
#define DIGIT_THREE  	0xB0
#define DIGIT_FOUR  	0x99
#define DIGIT_FIVE  	0x92
#define DIGIT_SIX  		0x82
#define DIGIT_SEVEN  	0xF8
#define DIGIT_EIGHT  	0x80
#define DIGIT_NINE  	0x90
#define DIGIT_DASH  	0xBF

#define LETTER_A        0b10001000 // from this line onward, I define my own letters based on the 7seg display architecture. they are displayed in binary as per the 0b suffix
#define LETTER_b        0b10000011
#define LETTER_d        0b10100001
#define LETTER_M        0b11001000
#define LETTER_L        0b11000111
#define LETTER_t        0b10001111
#define LETTER_r        0b10101111
#define LETTER_E        0b10000110
#define LETTER_P        0b10001100
#define LETTER_u        0b11100011
#define LETTER_c        0b10100111
#define LETTER_q        0b10011000
// 5 can be used for S, 1 can be used for I, and 0 can be used for O



#define NUMBER_BLANK  	10 	// Note: since 10 cannot be a digit,
 						   	//       it is used to represent a blank digit
#define NUMBER_DASH  	11 	// Note: since 11 cannot be a digit,
 						   	//       it is used to represent "dash"
#define LET_A        12     // from this line onward, my own letter cases are placed into the switch for use
#define LET_b        13
#define LET_d        14
#define LET_M        15
#define LET_L        16
#define LET_t        17
#define LET_r        18
#define LET_E        19
#define LET_P        20
#define LET_u        21
#define LET_c        22
#define LET_q        23

// Definitions for digit selection codes
#define EN_FIRST_SEG	0b0111
#define EN_SECOND_SEG	0b1011
#define EN_THIRD_SEG	0b1101
#define EN_FOURTH_SEG	0b1110

void print(char *str);

int setUpInterruptSystem();
void hwTimerISR(void *CallbackRef);
void displayNumber(u32 number);
void calculateDigits(u32 number);
void displayDigit();

#endif
