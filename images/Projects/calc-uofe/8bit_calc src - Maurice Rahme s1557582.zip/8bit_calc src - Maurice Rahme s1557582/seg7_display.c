#include <stdio.h>
#include "xil_types.h"		// Added for integer type definitions
#include "seg7_display.h"	// Added for 7-segment definitions
#include "gpio_init.h"

u8 digitDisplayed = FALSE;
u8 digits[4];
u8 numOfDigits;
u8 digitToDisplay;
u8 digitNumber;

void displayNumber(u32 number)
{   /* The biggest 16bit number is 65535. This information will be used to select the codewords for the letter conditions in such a way that the codeword
     * be achieved as a result on accident. Hence,I've chosen codewords such as 10001, 10007, 10017; such that they cannot be achieved using the switches, but also
     * are greater than 4 digits and don't satisfy the if statement which will trigger the dashes to signal an out of range number.
     *
     * number was declared as u32 in order to detect numbers greater than the greatest 16bit number.
     */

	u8 count;
	/* Note that 9999 is the maximum number that can be displayed
	 * Therefore, check if the number is less than or equal to 9999
	 * and display the number otherwise, display dashes in all the four segments
	 */
	if (number <= 9999)
	{
		// Call the calculateDigits method to determine the digits of the number
		calculateDigits(number);
		/* Do not display leading zeros in a number,
		 * but if the entire number is a zero, it should be displayed.
		 * By displaying the number from the last digit, it is easier
		 * to avoid displaying leading zeros by using the numOfDigits variable
		 */
		count = 4;
		while (count > 4 - numOfDigits)
		{
			digitToDisplay = digits[count-1];
			digitNumber = count;
			count--;
			/* Wait for timer interrupt to occur and ISR to finish
			 * executing digit display instructions
			 */
			while (digitDisplayed == FALSE);
			digitDisplayed = FALSE;
		}

	} else if (number == 10001){ //Calc
			digitToDisplay = LET_c;
			digitNumber = 1;
			while (digitDisplayed == FALSE);
			digitDisplayed = FALSE;

			digitToDisplay = LET_A;
			digitNumber = 2;
			while (digitDisplayed == FALSE);
			digitDisplayed = FALSE;

			digitToDisplay = LET_L;
			digitNumber = 3;
			while (digitDisplayed == FALSE);
			digitDisplayed = FALSE;

			digitToDisplay = LET_c;
			digitNumber = 4;
			while (digitDisplayed == FALSE);
			digitDisplayed = FALSE;

	}else if (number == 10003){ //Add
		digitToDisplay = LET_A;
		digitNumber = 1;
		while (digitDisplayed == FALSE);
		digitDisplayed = FALSE;
		
		digitToDisplay = LET_d;
		digitNumber = 2;
		while (digitDisplayed == FALSE);
		digitDisplayed = FALSE;
		
		digitToDisplay = LET_d;
		digitNumber = 3;
		while (digitDisplayed == FALSE);
		digitDisplayed = FALSE;
		
		digitToDisplay = NUMBER_BLANK;
		digitNumber = 4;
		while (digitDisplayed == FALSE);
		digitDisplayed = FALSE;



	}else if (number == 10007){ //Sub
		digitToDisplay = 5;
		digitNumber = 1;
		while (digitDisplayed == FALSE);
		digitDisplayed = FALSE;
		
		digitToDisplay = LET_u;
		digitNumber = 2;
		while (digitDisplayed == FALSE);
		digitDisplayed = FALSE;
		
		digitToDisplay = LET_b;
		digitNumber = 3;
		while (digitDisplayed == FALSE);
		digitDisplayed = FALSE;

		digitToDisplay = NUMBER_BLANK;
		digitNumber = 4;
		while (digitDisplayed == FALSE);
		digitDisplayed = FALSE;


	}else if (number == 10009){ //Mult
		digitToDisplay = LET_M;
		digitNumber = 1;
		while (digitDisplayed == FALSE);
		digitDisplayed = FALSE;
		
		digitToDisplay = LET_u;
		digitNumber = 2;
		while (digitDisplayed == FALSE);
		digitDisplayed = FALSE;
		
		digitToDisplay = LET_L;
		digitNumber = 3;
		while (digitDisplayed == FALSE);
		digitDisplayed = FALSE;

		digitToDisplay = LET_t;
		digitNumber = 4;
		while (digitDisplayed == FALSE);
		digitDisplayed = FALSE;


	}else if (number == 10011){ //Div
		digitToDisplay = LET_d;
		digitNumber = 1;
		while (digitDisplayed == FALSE);
		digitDisplayed = FALSE;
		
		digitToDisplay = 1;
		digitNumber = 2;
		while (digitDisplayed == FALSE);
		digitDisplayed = FALSE;
		
		digitToDisplay = LET_u;
		digitNumber = 3;
		while (digitDisplayed == FALSE);
		digitDisplayed = FALSE;

		digitToDisplay = NUMBER_BLANK;
		digitNumber = 4;
		while (digitDisplayed == FALSE);
		digitDisplayed = FALSE;


	}else if (number == 10013){ //Pow
		digitToDisplay = LET_P;
		digitNumber = 1;
		while (digitDisplayed == FALSE);
		digitDisplayed = FALSE;
		
		digitToDisplay = 0;
		digitNumber = 2;
		while (digitDisplayed == FALSE);
		digitDisplayed = FALSE;
		
		digitToDisplay = LET_u;
		digitNumber = 3;
		while (digitDisplayed == FALSE);
		digitDisplayed = FALSE;
		
		digitToDisplay = LET_u;
		digitNumber = 4;
		while (digitDisplayed == FALSE);
		digitDisplayed = FALSE;


	}else if (number == 10017){ //Sqrt
		digitToDisplay = 5;
		digitNumber = 1;
		while (digitDisplayed == FALSE);
		digitDisplayed = FALSE;

		digitToDisplay = LET_q;
		digitNumber = 2;
		while (digitDisplayed == FALSE);
		digitDisplayed = FALSE;
		
		digitToDisplay = LET_r;
		digitNumber = 3;
		while (digitDisplayed == FALSE);
		digitDisplayed = FALSE;
		
		digitToDisplay = LET_t;
		digitNumber = 4;
		while (digitDisplayed == FALSE);
		digitDisplayed = FALSE;

	} else if  (number == 10019){ //Sqr (square)

		digitToDisplay = 5;
		digitNumber = 1;
		while (digitDisplayed == FALSE);
		digitDisplayed = FALSE;

		digitToDisplay = LET_q;
		digitNumber = 2;
		while (digitDisplayed == FALSE);
		digitDisplayed = FALSE;

		digitToDisplay = LET_r;
		digitNumber = 3;
		while (digitDisplayed == FALSE);
		digitDisplayed = FALSE;

		digitToDisplay = NUMBER_BLANK;
		digitNumber = 4;
		while (digitDisplayed == FALSE);
		digitDisplayed = FALSE;


	} else if  (number == 10021){ // Err - This message is used for errors, such as dividing by zero

			digitToDisplay = LET_E;
			digitNumber = 1;
			while (digitDisplayed == FALSE);
			digitDisplayed = FALSE;

			digitToDisplay = LET_r;
			digitNumber = 2;
			while (digitDisplayed == FALSE);
			digitDisplayed = FALSE;

			digitToDisplay = LET_r;
			digitNumber = 3;
			while (digitDisplayed == FALSE);
			digitDisplayed = FALSE;

			digitToDisplay = NUMBER_BLANK;
			digitNumber = 4;
			while (digitDisplayed == FALSE);
			digitDisplayed = FALSE;



	} else if (number <= 65535){ // LED - this message means that the number is too great for the 7seg display, but it can be and has been displayed on the LED as a binary number
		digitToDisplay = LET_L;
		digitNumber = 1;
		while (digitDisplayed == FALSE);
		digitDisplayed = FALSE;

		digitToDisplay = LET_E;
		digitNumber = 2;
		while (digitDisplayed == FALSE);
		digitDisplayed = FALSE;

		digitToDisplay = LET_d;
		digitNumber = 3;
		while (digitDisplayed == FALSE);
		digitDisplayed = FALSE;

		digitToDisplay = NUMBER_BLANK;
		digitNumber = 4;
		while (digitDisplayed == FALSE);
		digitDisplayed = FALSE;

	}

	else if (number > 65535){
		// Display "----" to indicate that the number is out of range. number was declared as u32 in order to catch numbers greater than the greatest 16bit number 65535
		count = 1;
		while (count < 5)
		{
			digitToDisplay = NUMBER_DASH;
			digitNumber = count;
			count++;
			/* Wait for timer interrupt to occur and ISR to finish
			 * executing digit display instructions
			 */
			while (digitDisplayed == FALSE);
			digitDisplayed = FALSE;
		}
	}
}

void calculateDigits(u32 number)
{
	u8 fourthDigit;
	u8 thirdDigit;
	u8 secondDigit;
	u8 firstDigit;

	// Check if number is up to four digits
	if (number > 999)
	{
		numOfDigits = 4;

		fourthDigit  = number % 10;
		thirdDigit = (number / 10) % 10;
		secondDigit  = (number / 100) % 10;
		firstDigit = number / 1000;
	}
	// Check if number is three-digits long
	else if (number > 99 && number < 1000)
	{
		numOfDigits = 3;

		fourthDigit  = number % 10;
		thirdDigit = (number / 10) % 10;
		secondDigit  = (number / 100) % 10;
		firstDigit = 0;
	}
	// Check if number is two-digits long
	else if (number > 9 && number < 100)
	{
		numOfDigits = 2;

		fourthDigit  = number % 10;
		thirdDigit = (number / 10) % 10;
		secondDigit  = 0;
		firstDigit = 0;
	}
	// Check if number is one-digit long
	else if (number >= 0 && number < 10)
	{
		numOfDigits = 1;

		fourthDigit  = number % 10;
		thirdDigit = 0;
		secondDigit  = 0;
		firstDigit = 0;
	}

	digits[0] = firstDigit;
	digits[1] = secondDigit;
	digits[2] = thirdDigit;
	digits[3] = fourthDigit;

	return;
}

void displayDigit()
{
	/*
	 * This timer ISR is used to display the digits
	 */
	switch (digitToDisplay)
	{
		case NUMBER_BLANK :
			XGpio_DiscreteWrite(&SEG7_HEX_OUT, 1, DIGIT_BLANK);
			break;
		case 0 :
			XGpio_DiscreteWrite(&SEG7_HEX_OUT, 1, DIGIT_ZERO);
			break;
		case 1 :
			XGpio_DiscreteWrite(&SEG7_HEX_OUT, 1, DIGIT_ONE);
			break;
		case 2 :
			XGpio_DiscreteWrite(&SEG7_HEX_OUT, 1, DIGIT_TWO);
			break;
		case 3 :
			XGpio_DiscreteWrite(&SEG7_HEX_OUT, 1, DIGIT_THREE);
			break;
		case 4 :
			XGpio_DiscreteWrite(&SEG7_HEX_OUT, 1, DIGIT_FOUR);
			break;
		case 5 :
			XGpio_DiscreteWrite(&SEG7_HEX_OUT, 1, DIGIT_FIVE);
			break;
		case 6 :
			XGpio_DiscreteWrite(&SEG7_HEX_OUT, 1, DIGIT_SIX);
			break;
		case 7 :
			XGpio_DiscreteWrite(&SEG7_HEX_OUT, 1, DIGIT_SEVEN);
			break;
		case 8 :
			XGpio_DiscreteWrite(&SEG7_HEX_OUT, 1, DIGIT_EIGHT);
			break;
		case 9 :
			XGpio_DiscreteWrite(&SEG7_HEX_OUT, 1, DIGIT_NINE);
			break;
		case NUMBER_DASH :
			XGpio_DiscreteWrite(&SEG7_HEX_OUT, 1, DIGIT_DASH);
			break;
		case LET_A :                                         // from this line onward, my own letter cases are placed into the switch for use
			XGpio_DiscreteWrite(&SEG7_HEX_OUT, 1, LETTER_A);
			break;
		case LET_b :
			XGpio_DiscreteWrite(&SEG7_HEX_OUT, 1, LETTER_b);
			break;
		case LET_d :
			XGpio_DiscreteWrite(&SEG7_HEX_OUT, 1, LETTER_d);
			break;
		case LET_M :
			XGpio_DiscreteWrite(&SEG7_HEX_OUT, 1, LETTER_M);
			break;
		case LET_L :
			XGpio_DiscreteWrite(&SEG7_HEX_OUT, 1, LETTER_L);
			break;
		case LET_t :
			XGpio_DiscreteWrite(&SEG7_HEX_OUT, 1, LETTER_t);
			break;
		case LET_r :
			XGpio_DiscreteWrite(&SEG7_HEX_OUT, 1, LETTER_r);
			break;
		case LET_E :
			XGpio_DiscreteWrite(&SEG7_HEX_OUT, 1, LETTER_E);
			break;
		case LET_P :
			XGpio_DiscreteWrite(&SEG7_HEX_OUT, 1, LETTER_P);
			break;
		case LET_u :
			XGpio_DiscreteWrite(&SEG7_HEX_OUT, 1, LETTER_u);
			break;
		case LET_c :
			XGpio_DiscreteWrite(&SEG7_HEX_OUT, 1, LETTER_c);
			break;
		case LET_q :
			XGpio_DiscreteWrite(&SEG7_HEX_OUT, 1, LETTER_q);
			break;

		default:
			break;
	}

	// Select the appropriate digit
	if (digitNumber == 1) {
		XGpio_DiscreteWrite(&SEG7_SEL_OUT, 1, EN_FIRST_SEG);
	}
	else if (digitNumber == 2) {
		XGpio_DiscreteWrite(&SEG7_SEL_OUT, 1, EN_SECOND_SEG);
	}
	else if (digitNumber == 3) {
		XGpio_DiscreteWrite(&SEG7_SEL_OUT, 1, EN_THIRD_SEG);
	}
	else if (digitNumber == 4) {
		XGpio_DiscreteWrite(&SEG7_SEL_OUT, 1, EN_FOURTH_SEG);
	}

	digitDisplayed = TRUE;
	return;
}
