#include <stdio.h>
#include "platform.h"
#include "xil_types.h"		// Added for integer type definitions
#include "seg7_display.h"	// Added for 7-segment definitions
#include "gpio_init.h"
#include <math.h>  // used for the abs, sqrt and pow functions


/* The following code will program the FPGA into a calculator which takes 8bit inputs and displays a 16bit result.
 * It can perform addition, subtraction, multiplication, division and exponentials.
 * These operations are controlled using the LEFT and RIGHT buttons on the FPGA, where hitting the former will move you forward, and the latter will move you back.
 *
 * Upon running the program, you will be met with the starting screen, which displays "cALc" on the 7 segment display, and turns on all the LEDs.
 * Your next step is to set up your desired variables for your operations. You can do this using the slide switches, where the first 8  from the right will form your first number
 * (in 8bit binary), and the second 8 will form your second number (in 8bit binary). You can change these numbers at any time for different results.
 * If you press the left button once, you will be shown the first operation mode's name; in this case "Add". Upon pressing it the second time, you will be shown the result, both on
 * the 7segment display and on the LEDs (in binary format).
 * This holds true for all subsequent operations.
 *
 * The program can also show you the square root and the square of the result achieved by the initial operations. This is the advanced function.
 * It is controlled by using the UP and DOWN buttons, and works in the same way as the initial operation types.
 * You can get out of the advanced calculator by pressing UP or DOWN until you see the result of the basic operation you were in.
 * press the centre button to reset the calculator if needed.
 *
 * SPECIAL CONDITIONS:
 * Dividing by zero will display "Err" on the 7segment display
 * If your result is greater than 9999, but smaller or equal to the greatest 16bit number (65535), then the calculator will display LED on the 7segment display, but will
 * still display the result in 16bit binary using the LEDs.
 * if your result is greater than 65535, the calculator will display "----" and turn on all the LEDs to signal that the number is out of range.
 */


// Global variables ; declare and define required variables

	u16 slideSwitchIn = 0;
	u16 tempnum1 = 0b0000000011111111; // 0b signals the code to read and in binary
	u16 tempnum2 = 0b1111111100000000;
	u16 num1;
	u16 num2;
	volatile u16 counter =0;
	volatile u16 extra =0;
	u32 result;
	u32 showled;  // this variable is used to output to the LEDs. Its main use is in error conditions, where we don't want to display the result in 16bit anymore using the LEDs
	u16 pushBtnLeftIn = 0;
    u16 pushBtnRightIn = 0;
    u16 pushBtnUpIn = 0;
    u16 pushBtnDownIn = 0;
    u16 ledcount = 0; // count variable dedicated to LED OUT that is used to show the count of the ascending order of the operation types





// initialization code
int initialize();


// button push counter retrieval code
int getcounters();


// input detection code
int inputs();


// Left/Right counter condition code
int countercondition();


// Up/Down counter condition code
int extracountercondition();


// LED condition code
int ledcondition();






// Adder code
u16 adder(u16 augend, u16 addend);

// Subtractor code
u16 subtractor(u16 minuend, u16 subtrahend);

// Multiplicator code
u16 multiplicator(u16 multiplicand, u16 multiplier);

// Divider code
u16 divider(u16 dividend, u16 divisor);










int main()
{    
	init_platform();
	
	// initialization code - Initialize the GPIOs and setup the Interrupt System
	initialize();

    // this is the main while(1) loop where all of the post-initialization code occurs. I placed it into this function to clean up the main
	while (1)
			{

			         // Input Function:
			         // this code reads the switch inputs and button inputs. It then assigns the first 8 switches to an 8bit number combination,
			         // and the second set of 8 switches to an equivalent 8bit number combination by shifting them to the right by 8 spaces
			         // it ret
				     inputs();

				     // getcounters Function:
		             // from the "inputs" function, this code reads the input buttons, left, right, up, and down, and returns two counter values
				     // the first counter, "counter", is controlled by the left(++) and right(--) buttons
				     // the second counter, "extra", is controlled by the up(++) and down(--) buttons
					 getcounters();

					 // countercondition Function:
					 // this code reads the counter return called "counter" from the "getcounters" code, and uses in an if statement
					 // note that I changed number from 16bit to 32bit, as it needs to be greater than 16bit in order to display the error message, whose condition is that the number is
					 // greater than 16bits
		             countercondition();



		             // extracountercondition Function:
		             // this behaves similarly to the above function, but can calculate and show the square or square root of the above result
		             extracountercondition();



		             // ledcondition Function:
		             // this code tells the LED display whether to display the operation order number, or the operation's result in 16bit format, depending on the counter values
		             // example case: if the user has tried to find the square (extra function) of the result of a division, the LEDs will still display 0b"100" to tell the user
		             // that they are still in the division mode
		             ledcondition();


					 displayNumber(result);


			}

    cleanup_platform();
    return 0;
}










//initialization code
int initialize(){
	int status;

	    // Initialize the GPIOs
	    status = initGpio();
		if (status != XST_SUCCESS) {
			print("GPIOs initialization failed!\n\r");
			cleanup_platform();
			return 0;
		}

		// Setup the Interrupt System
		status = setUpInterruptSystem();
		if (status != XST_SUCCESS) {
			print("Interrupt system setup failed!\n\r");
			cleanup_platform();
			return 0;
		}
		return 0;
}


// button push counter retrieval code
int getcounters(){

	                        // Check if LEFT button has been pressed
				            if (pushBtnLeftIn == 1) {
							// Wait for the button to be released

							while (pushBtnLeftIn == 1){ // while loop allows for repress since it takes up 1 clock cycle

								pushBtnLeftIn = XGpio_DiscreteRead(&P_BTN_LEFT, 1);
							}
							// Increment counter
							counter++;
				            }


				            // Check if RIGHT button has been pressed
				            if (pushBtnRightIn == 1) {
							// Wait for the button to be released

							while (pushBtnRightIn == 1){ // while loop allows for repress since it takes 1 clock cycle
							
								pushBtnRightIn = XGpio_DiscreteRead(&P_BTN_RIGHT, 1);
							}
							// decrease counter
						if (!counter) counter=10; // when !counter means: when the counter is less than 1. this is written here to overwrite a possibly changed counter in subsequent functions
							counter--;
						}


				            // Check if UP button has been pressed
				            if (pushBtnUpIn == 1) {
				            // Wait for the button to be released

				            while (pushBtnUpIn == 1){ // while loop allows for repress since it takes 1 clock cycle

				            pushBtnUpIn = XGpio_DiscreteRead(&P_BTN_UP, 1);
				            }
				           // Increment counter
				            extra++;
				            }


				            // Check if DOWN button has been pressed
				            if (pushBtnDownIn == 1) {
				            // Wait for the button to be released

				            while (pushBtnDownIn == 1){ // while loop allows for repress since it takes 1 clock cycle

				            pushBtnDownIn = XGpio_DiscreteRead(&P_BTN_DOWN, 1);
				            }

				            // decrease counter
				            if (!extra) extra=4; // same as above
				            extra--;
				           }

				            return 0;
}


// input detection code
int inputs(){
	// Read the input switches and buttons to determine the desired number and operation inputs
	
	        // Read the number input switches
			slideSwitchIn = XGpio_DiscreteRead(&SLIDE_SWITCHES, 1);

			num1 = (slideSwitchIn&tempnum1); // AND gate with the tempnum1 mask which subsequently only allows switches 0 to 7 to be stored as num1
			num2 = (slideSwitchIn&tempnum2)>> 8; /* AND gate with the tempnum1 mask which subsequently only allows switches 0 to 7 to be stored as num1. The result is shifted
			to the right by 8 bits using ">>" as per the LEDshift code in lab 2; this allows the num2 inputs to be stored as an 8bit binary number starting from 1 (ON), as opposed to 256
			*/
			
			

			// Read the operation input buttons
			pushBtnLeftIn = XGpio_DiscreteRead(&P_BTN_LEFT, 1); // Read Left Button
			pushBtnRightIn = XGpio_DiscreteRead(&P_BTN_RIGHT, 1); // Read Right Button
			pushBtnUpIn = XGpio_DiscreteRead(&P_BTN_UP, 1); // Read Up Button
			pushBtnDownIn = XGpio_DiscreteRead(&P_BTN_DOWN, 1); // Read Down Button

            return 0;
}


// Left/Right counter condition code
int countercondition(){

								   
								    /* The if else statements allow for backwards looping using the right button.
									
									Upon reading the "counter" return from the getcounters Function, it recognizes
									if the counter value is equal to !counter [i.e. counter <1], it puts the calculator 
									in its starting position, which turns on all of the LEDs via the binary code sent to "ledcount",
									which is the corresponding input to the "ledcondition" Function, which writes to the LEDs.
									It also diplays "cALc" on the 7-segment display by setting "result" equal to the codeword for "cALc"
									that I have created. This codeword, along with all letter-display codeworks in this function is 
									greater than the largest 32-bit number, 2147483647 to prevent the calculator from unintentionally displaying 
									letters instead of the correct result. result is then called in the "infiniteloop" Function as an input to
									the "displayNumber" Function which outputs to the 7-segment display.									
									*/
	                               if (!counter){
	                                	ledcount = 0b1111111111111111;
	                                	result = 10001; // Show cALc

	                               }else if (counter ==1){
		                            	// display "Add" on the 7segment display, by the same method described above
		                            	result = 10003;
		                            	ledcount = 1;


	                               } else if (counter == 2){
									// perform addition
							        result = adder (num1, num2);
							        showled = result;


	                               } else if (counter == 3){
										// display "Sub" on the 7segment display, by the same method described above
										result = 10007;
		                            	ledcount = 2;


	                               } else if (counter == 4){
									// perform subtraction
									result = subtractor (num1, num2);
									showled = result;


	                               } else if (counter == 5){
								    	// display "MuLt" on the 7segment display, by the same method described above
								    	result = 10009;
		                            	ledcount = 3;


	                               } else if (counter == 6){
									//perform multiplication
									result= multiplicator (num1, num2);
									showled = result;


	                               } else if (counter == 7){
										// display "div" on the 7segment display, by the same method described above
										result = 10011;
		                            	ledcount = 4;


	                               } else if  (counter == 8){
									//perform division
									if (num2 == 0){ /* dividing by 0 displays an error by force setting the result to 10009, which
									is a codeword I have assigned to display an error message on the 7-segment display since it is greater
									than the largest possible 16bit number, and hence cannot be displayed neither on the 7seg nor on the LEDs
									this code is visible in the seg7_display.c file. 
									*/
									result = 10021;
									showled = 0; // this is set here so that the LEDs don't try to show 10009 in binary for this error
									}else {
									result = divider (num1, num2);
									}


	                               } else if (counter ==9){
								    	// display "Pow" on the 7segment display, by the same method described above
								    	result = 10013;
		                            	ledcount = 5;


	                               } else if (counter == 10){
								    // raise num1 to the power of num2
									result = pow(num1, num2);
									showled = result;


	                               } else if  (counter >= 11){
								   	counter = 0;
									}

	return 0;
}


// Up/Down counter condition code
int extracountercondition(){
                                // These if else statements allow for backwards looping using the right button.
									
																	
								

								/* the first condition is similar to the first one in the "countercondition" Function, except that it doesn't force display anything if !extra is true,
								and simply allows the 7seg display to show whatever is being forced by "counter" in the "countercondition" Function. */
								if (!extra){
								result = result;
								

								} else if  (extra ==1){
		                        // display "Sqrt" on the 7segment display, by the same method described in the "countercondition" Function
	                            result = 10017;


								} else if  (extra == 2){
							 	// perform square root of result
								if (result == 0 || result == 10001){ // this condition is here for the start screen case, where the calculator would otherwise think result = 10001
									result = 0;
								}else{
							 	result = sqrt(result);
								}


								} else if  (extra ==3){
		                        // display "Sqr" on the 7segment display, by the same method described above
	                            result = 10019;


								} else if  (extra == 4){
							 	// square result
								if (result == 10001){ // this condition is here for the start screen case, where the calculator would otherwise think result = 10001
									result = 0;
								}else{
							 	result = pow(result, 2);
								}

		                        
								} else if  (extra >= 5){
							 	extra = 0;
								
								}
	                            return 0;
}


// LED display conditions code - This function tells the LED whether to display the operation result, or operation mode number, as based by the counters "counter" and "extra"
int ledcondition(){

    // for the below conditions, the LED will display the operation mode number (for example: Add = display 1, Sub = display 2, etc..)
	if (counter == 0 || counter == 1 || counter == 3 || counter == 5 || counter == 7 || counter == 9 || extra == 1 || extra == 3 || extra == 5){
	XGpio_DiscreteWrite(&LED_OUT, 1, ledcount);
	} 
	// for the below conditions, the LED will display the result of the performed operation, except in the error cases.
	else if (counter == 2 || counter == 4 || counter == 6 || counter == 8 || counter == 10 || extra == 2 || extra == 4 || extra == 6){
	XGpio_DiscreteWrite(&LED_OUT, 1, showled);
						}
	return 0;
}






// Adder code
    u16 adder(u16 augend, u16 addend)
    {
    	u16 sum;
    	sum = augend + addend;
    	return sum;
    }

// Subtractor code
    u16 subtractor(u16 minuend, u16 subtrahend)
        {
    	 u16 difference;
         difference = abs(minuend - subtrahend); // absolute value of difference is displayed
         return difference;
        }

// Multiplicator code
    u16 multiplicator(u16 multiplicand, u16 multiplier)
    {
    	u16 multiple;
    	multiple = multiplicand * multiplier;
    	return multiple;
    }

// Divider code
    u16 divider(u16 dividend, u16 divisor)
        {
    	u16 division;
        	division = dividend / divisor;
        	return division;
        }
